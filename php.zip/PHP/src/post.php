<?php include_once("layout/header.php");

$currentPost = null;

if(isset($_GET['id'])){
    $postId = $_GET['id'];
    $currentPost;

    foreach($posts as $post){
        
        if($post['id'] == $postId){
            $currentPost = $post;
        }
    }
}
?>

<main id="posts-container">
    <div class="content-container">
        <h1 id="main-title"><?= $currentPost['title']?></h1>
        <p id="post-description"><?= $currentPost['description']?></p>
        <div class="img-container">
            <img src="<?=$BASE_URL?>/img/<?=$currentPost['img']?>" alt="<?=$currentPost['title']?>" > 
        </div>
        <p class="post-content">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis cupiditate inventore iusto. Pariatur, ipsum ducimus provident accusantium repudiandae voluptates temporibus molestias eum, adipisci obcaecati sunt iste unde deleniti inventore repellendus.
        Similique obcaecati ea magni magnam earum possimus assumenda minima sed maiores odit ratione repudiandae eveniet, quibusdam repellendus pariatur culpa corrupti incidunt ipsa vero architecto debitis hic consequuntur modi nobis. Beatae.
        Accusantium in perferendis, dolorum provident vitae, natus nobis est quas deleniti iste debitis placeat iusto adipisci deserunt delectus. Esse facilis fugit nam possimus quasi repellat! Aliquid assumenda dolorem repudiandae quisquam!
        Esse, obcaecati amet assumenda porro, facere ipsa ad dolorum voluptatum qui dicta expedita reprehenderit rerum distinctio sed quos voluptate consequuntur enim, ullam beatae. Incidunt est explicabo odit modi, minima tenetur?
        Quia animi impedit quasi est quam quibusdam incidunt eligendi aliquid explicabo cum nesciunt autem, ipsam quo tenetur neque magnam culpa tempora officia eaque, amet magni architecto esse blanditiis. Vitae, eaque! </p>

        <p class="post-content">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis cupiditate inventore iusto. Pariatur, ipsum ducimus provident accusantium repudiandae voluptates temporibus molestias eum, adipisci obcaecati sunt iste unde deleniti inventore repellendus.
        Similique obcaecati ea magni magnam earum possimus assumenda minima sed maiores odit ratione repudiandae eveniet, quibusdam repellendus pariatur culpa corrupti incidunt ipsa vero architecto debitis hic consequuntur modi nobis. Beatae.
        Accusantium in perferendis, dolorum provident vitae, natus nobis est quas deleniti iste debitis placeat iusto adipisci deserunt delectus. Esse facilis fugit nam possimus quasi repellat! Aliquid assumenda dolorem repudiandae quisquam!
        Esse, obcaecati amet assumenda porro, facere ipsa ad dolorum voluptatum qui dicta expedita reprehenderit rerum distinctio sed quos voluptate consequuntur enim, ullam beatae. Incidunt est explicabo odit modi, minima tenetur?
        Quia animi impedit quasi est quam quibusdam incidunt eligendi aliquid explicabo cum nesciunt autem, ipsam quo tenetur neque magnam culpa tempora officia eaque, amet magni architecto esse blanditiis. Vitae, eaque! </p>
    </div>
    <aside id="nav-container">
        <h3 id="tags-title">Tags</h3>
        <ul id="tag-list">
            <?php foreach($currentPost['tags'] as $tag): ?>
                <li><a href="#"><?= $tag ?></a></li>
            <?php endforeach;?>
        </ul>
        <h3 id="categories-title">Categorias</h3>
        <ul id="categories-list">
            <?php foreach($categories as $category): ?>
                <li><a href="#"><?= $category ?></a></li>
            <?php endforeach;?>
        </ul>
    </aside>
</main>
<?php include_once("layout/footer.php");?>