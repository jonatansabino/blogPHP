<footer>
    <p id="text">Blog PHP 2024 &copy;</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script>
    const textElement = document.getElementById('text');
    const textContent = textElement.innerHTML;
    textElement.innerHTML = '';
    
    function typeWriterEffect() {
      let i = 0;
      const typingInterval = setInterval(() => {
        textElement.innerHTML += textContent.charAt(i);
        i++;

        if (i > textContent.length) {
          clearInterval(typingInterval);
        }
      }, 100);
    }    
    typeWriterEffect();
  </script>  
</body>
</html>   