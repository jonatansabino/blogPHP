<?php include_once("helpers/url.php")?>
<?php include_once("data/categories.php")?>
<?php include_once("data/posts.php")?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php $BASE_URL?>css/style.css">  
    <link rel="stylesheet" href="<?php $BASE_URL?>css/responsive.css">  
    <title>Blog</title>
</head>
<body>
    <header>
        <a href="<?php $BASE_URL?>/" id="logo">
            <img src="<?php $BASE_URL?>/img/logo.svg" alt="Blog Codar" srcset="">
        </a>
        <nav>
            <ul id="navbar">
                <li><a href="<?php $BASE_URL ?>/" class="nav-link">Home <i class="fa fa-home" aria-hidden="true"></i></a></li>
                <li><a href="#" class="nav-link">Categorias <i class="fa fa-list" aria-hidden="true"></i></a></li>
                <li><a href="#" class="nav-link">Sobre <i class="fa fa-info-circle" aria-hidden="true"></i></a></li>
                <li><a href="<?php $BASE_URL ?>/contato.php" class="nav-link">Contato <i class="fa fa-address-book" aria-hidden="true"></i></a></li>
            </ul>
        </nav>
    </header>
    